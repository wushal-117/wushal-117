fit = GWQR(dp=dp, d=d, X=X, y=Y, h=50, kernel='bi-square',
          alpha=0.5, tau=0.5, iteration=20, fig=T)
